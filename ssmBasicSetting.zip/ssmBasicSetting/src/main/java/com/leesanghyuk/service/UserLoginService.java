package com.leesanghyuk.service;

import com.leesanghyuk.model.UserLoginDTO;

public interface UserLoginService {
    public String LoginCheck(UserLoginDTO userlogindto);
}