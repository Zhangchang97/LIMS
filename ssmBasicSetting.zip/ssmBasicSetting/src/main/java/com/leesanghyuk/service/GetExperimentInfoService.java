package com.leesanghyuk.service;

import com.leesanghyuk.model.ExperimentInfoDTO;

import java.util.List;

public interface GetExperimentInfoService {
    public List<ExperimentInfoDTO> getExperimentInfo();
}
